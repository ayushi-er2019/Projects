import ListApp from './ListApp.js';

function App() {
  return (
    <ListApp/>
  );
}

export default App;
